from django.contrib import admin
from . import models

admin.site.register(models.Profile)
admin.site.register(models.Blog)
admin.site.register(models.Qualification)
admin.site.register(models.Skills)
admin.site.register(models.Contactus)
